#include<iostream>
#include<cstring>
#include "tuyen.h"
using namespace std;

int main()
{
	nguoi nguoi1;
	GVCN gv1;
	gv1.nhap();
	gv1.xuat();
	
	return 0;
}

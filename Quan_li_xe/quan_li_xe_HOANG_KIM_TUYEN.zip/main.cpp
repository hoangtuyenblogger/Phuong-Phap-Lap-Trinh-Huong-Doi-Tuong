#include<iostream>
#include"tuyen.h"
using namespace std;


int main()
{
	xe *xe_ne; // tao 1 con tro xe
	
	cout<<"\nThong tin cua class xe : \n";
	xe_ne = new xe(2010,500);
	xe_ne->xuat();
	delete xe_ne;
	
	
	cout<<"\nThong tin cua class xe tai : \n";
	xe_ne = new xetai(2019,500,1500);
	xe_ne->xuat();
	delete xe_ne;
	return 0;
}

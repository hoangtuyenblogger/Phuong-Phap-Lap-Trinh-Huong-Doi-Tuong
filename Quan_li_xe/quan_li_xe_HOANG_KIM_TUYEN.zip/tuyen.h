#pragma once
class xe
{
	private:
			int namsx;
			int trongluong;
	public:
			xe(int _namsx, int _trongluong);
			virtual float giathanh();
			virtual void xuat();
};

class xetai : public xe
{
	private:
		int trongtai;
	public:
		xetai(int _namsx, int _trongluong, int _trongtai);
		float giathanh();
		void xuat();
};
